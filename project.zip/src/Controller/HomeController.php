<?php

namespace App\Controller;

use App\Entity\User;
use App\Repository\BookReadRepository;
use App\Repository\BookRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManager;

class HomeController extends AbstractController
{
    private BookReadRepository $bookReadRepository;
    private  $entityManager;

    public function __construct(BookReadRepository $bookReadRepository)
    {
        $this->bookReadRepository = $bookReadRepository;
    }

    #[Route('/', name: 'app.home')]
    public function index(): Response
    {
        $user = $this->getUser(); // get user

        if (!$user instanceof User) { // if user not connected
            return $this->redirectToRoute('auth.login');
        }

        $userId = $user->getId(); // get user id

        $booksRead = $this->bookReadRepository->findByUserId($userId, false); // get books readed by user

        return $this->render('pages/home.html.twig', [
            'booksRead' => $booksRead,
            'name'      => 'Accueil', // Pass data to the view
        ]);
    }

    
}